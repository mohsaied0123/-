package com.mohamed.yawmak

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface

class Bridge(private val a: Activity) {

    @JavascriptInterface
    fun hasAccess(): Boolean = Usage.hasAccess(a)

    @JavascriptInterface
    fun openAccess() {
        a.runOnUiThread {
            try {
                a.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + a.packageName)))
            } catch (e: Exception) {
                a.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
    }

    @JavascriptInterface
    fun getDay(d: String): String = try {
        Usage.dayJson(a, d)
    } catch (e: Exception) {
        "[]"
    }

    @JavascriptInterface
    fun setLabel(key: String, label: String) {
        Labels.set(a, key, label)
    }

    @JavascriptInterface
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) {
            a.runOnUiThread {
                a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }
}
