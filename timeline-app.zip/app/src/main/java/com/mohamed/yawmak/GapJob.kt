package com.mohamed.yawmak

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import java.time.LocalDate
import java.util.Calendar

// Runs about once an hour. If there are finished gaps (30 min or more) without a label, posts a reminder.
class GapJob : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try {
                scan(applicationContext)
            } catch (e: Exception) {
                // ignore
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = false

    companion object {
        private const val ID = 7

        fun schedule(c: Context) {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (js.allPendingJobs.any { it.id == ID }) return
            val job = JobInfo.Builder(ID, ComponentName(c, GapJob::class.java))
                .setPeriodic(60 * 60_000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        }

        private fun scan(c: Context) {
            if (!Usage.hasAccess(c)) return
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (hour < 8 || hour >= 23) return
            val now = System.currentTimeMillis()
            val prefs = c.getSharedPreferences("app", Context.MODE_PRIVATE)
            if (now - prefs.getLong("lastNotif", 0L) < 3 * 3_600_000L) return

            val arr = JSONArray(Usage.dayJson(c, LocalDate.now().toString()))
            var count = 0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val len = o.getLong("e") - o.getLong("s")
                val done = o.getLong("e") < now - 5 * 60_000L
                if (o.getString("t") == "off" && o.getString("l").isEmpty() && len >= 30 * 60_000L && done) count++
            }
            if (count == 0) return

            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("gaps", "تذكير التسمية", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val note = Notification.Builder(c, "gaps")
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setContentTitle("يومك")
                .setContentText("عندك $count فترة من غير تسمية، اضغط وسمّيها")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(1, note)
            prefs.edit().putLong("lastNotif", now).apply()
        }
    }
}
