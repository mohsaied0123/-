package com.mohamed.yawmak

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId

data class Seg(val s: Long, val e: Long, val type: String, val label: String, val key: String = "")

object Labels {
    private fun prefs(c: Context) = c.getSharedPreferences("labels", Context.MODE_PRIVATE)

    fun get(c: Context, k: String): String = prefs(c).getString(k, "") ?: ""

    fun set(c: Context, k: String, v: String) {
        prefs(c).edit().putString(k, v).apply()
    }
}

object Usage {
    const val GAP = 15 * 60_000L
    private const val HALF_DAY = 12 * 3_600_000L
    private val SKIP = setOf("com.android.systemui", "com.samsung.android.app.aodservice")

    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun appName(c: Context, p: String): String = try {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
    } catch (e: Exception) {
        p
    }

    private fun gap(c: Context, s: Long, e: Long): Seg {
        val k = (s / 60_000L).toString()
        return Seg(s, e, "off", Labels.get(c, k), k)
    }

    // Builds app-usage segments from system usage events, and inserts "off" gaps (15 min or more).
    // Event types: 1 = activity resumed, 2 = activity paused, 16 = screen non-interactive, 26 = device shutdown.
    fun segs(c: Context, from: Long, to: Long): List<Seg> {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ev = um.queryEvents(from, to) ?: return emptyList()
        val e = UsageEvents.Event()
        val raw = ArrayList<Triple<String, Long, Long>>()
        var cur = ""
        var st = 0L
        var paused = 0L

        fun close(t: Long) {
            if (cur.isNotEmpty() && t > st) raw.add(Triple(cur, st, t))
            cur = ""
            paused = 0L
        }

        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val t = e.timeStamp
            val p = e.packageName ?: ""
            when (e.eventType) {
                1 -> if (p.isNotEmpty() && p !in SKIP && p != c.packageName) {
                    if (cur == p) {
                        paused = 0L
                    } else {
                        close(if (paused > 0) paused else t)
                        cur = p
                        st = t
                    }
                }
                2 -> if (p == cur && paused == 0L) paused = t
                16, 26 -> close(if (paused > 0) paused else t)
            }
        }
        if (cur.isNotEmpty()) close(if (paused > 0) paused else minOf(to, System.currentTimeMillis()))

        val names = HashMap<String, String>()
        val apps = ArrayList<Seg>()
        for ((p, s, en) in raw) {
            val name = names.getOrPut(p) { appName(c, p) }
            val last = apps.lastOrNull()
            if (last != null && last.label == name && s - last.e < 10_000) {
                apps[apps.size - 1] = last.copy(e = en)
            } else {
                apps.add(Seg(s, en, "app", name))
            }
        }

        val out = ArrayList<Seg>()
        var prevEnd = -1L
        for (a in apps.filter { it.e - it.s >= 3_000 }) {
            if (prevEnd >= 0 && a.s - prevEnd >= GAP) out.add(gap(c, prevEnd, a.s))
            out.add(a)
            prevEnd = a.e
        }
        if (prevEnd >= 0 && to - prevEnd >= GAP) out.add(gap(c, prevEnd, to))
        return out
    }

    // JSON for one local day (yyyy-MM-dd): [{s,e,t:"app"|"off",l:label,k:gapKey}]
    fun dayJson(c: Context, d: String): String {
        if (!hasAccess(c)) return "[]"
        val zone = ZoneId.systemDefault()
        val day = LocalDate.parse(d)
        val ds = day.atStartOfDay(zone).toInstant().toEpochMilli()
        val de = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val to = minOf(de + HALF_DAY, System.currentTimeMillis())
        if (to <= ds) return "[]"
        val arr = JSONArray()
        for (s in segs(c, ds - HALF_DAY, to)) {
            val a = maxOf(s.s, ds)
            val b = minOf(s.e, de)
            if (b - a >= 3_000) {
                arr.put(JSONObject().put("s", a).put("e", b).put("t", s.type).put("l", s.label).put("k", s.key))
            }
        }
        return arr.toString()
    }
}
